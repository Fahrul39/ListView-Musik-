package com.example.musiklistview;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;

public class MusikAdapter extends BaseAdapter {
    public MusikAdapter(Context context) {
        this.context = context;
        music = new ArrayList<>();
    }

    private final Context context;

    public void setMusic(ArrayList<Music> music) {
        this.music = music;
    }

    private ArrayList<Music> music;

    @Override
    public int getCount() {
        return music.size();
    }

    @Override
    public Object getItem(int i) {
        return music.get(i);
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        if (view == null){
            view = LayoutInflater.from(context).inflate(R.layout.musik_list,viewGroup,false);
        }
        ViewHolder viewHolder = new ViewHolder(view);
        Music music = (Music) getItem(i);
        viewHolder.bind(music);
        return view;
    }
    private class ViewHolder {
        private TextView txtName;
        private TextView txtDescription;
        private ImageView imgPhoto;

        ViewHolder(View view){
            txtName = view.findViewById(R.id.txt_name);
            txtDescription = view.findViewById(R.id.txt_description);
            imgPhoto = view.findViewById(R.id.img_photo);
        }
        void bind(Music music){
            txtName.setText(music.getName());
            txtDescription.setText(music.getDescription());
            imgPhoto.setImageResource(music.getPhoto());
        }
    }
}
